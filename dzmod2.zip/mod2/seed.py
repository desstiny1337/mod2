import sqlite3
from faker import Faker

# connecting to db
con = sqlite3.connect('tasks_management.db')
cursor = con.cursor()

#faker
fake = Faker()

status_values = [('new',), ('in progress',), ('completed',)]
cursor.executemany("INSERT INTO status (name) VALUES (?)", status_values)

for _ in range(10):
    fullname = fake.name()
    email = fake.email()
    cursor.execute("INSERT INTO users (fullname, email) VALUES (?, ?)", (fullname, email))

for _ in range(20):
    title = fake.sentence(nb_words=6)
    description = fake.text(max_nb_chars=200)
    status_id = fake.random_int(min=1, max=3)
    user_id = fake.random_int(min=1, max=10)
    cursor.execute("INSERT INTO tasks (title, description, status_id, user_id) VALUES (?, ?, ?, ?)", (title, description, status_id, user_id))

con.commit()
con.close()
